package com.cg.frs.dao;

import java.util.List;
import java.util.Map;

import com.cg.frs.beans.FlatOwner;
import com.cg.frs.utility.OwnerDb;

public class FlatRegistrationDaoImpl implements IFlatRegistrationDao {
	OwnerDb utility=new OwnerDb();
@Override
	public Map<Integer, FlatOwner> getList() {
		
		return OwnerDb.map;
	}

}
