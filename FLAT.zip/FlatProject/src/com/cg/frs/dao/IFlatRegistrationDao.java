package com.cg.frs.dao;

import java.util.Map;

import com.cg.frs.beans.FlatOwner;
import com.cg.frs.exception.OwnerException;

public interface IFlatRegistrationDao {
   Map<Integer,FlatOwner>getList() throws OwnerException;
   
	}


