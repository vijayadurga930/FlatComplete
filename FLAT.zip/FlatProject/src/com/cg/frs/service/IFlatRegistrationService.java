package com.cg.frs.service;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.frs.beans.FlatOwner;
import com.cg.frs.beans.FlatRegistrationDTO;
import com.cg.frs.exception.OwnerException;

public interface IFlatRegistrationService {
	FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) ;

    public  Map<Integer, FlatOwner> getAllOwnerIds();

	boolean isNamevalid(String ownername) throws OwnerException;

	boolean isPhonevalid(String Mobilenum) throws OwnerException;
	boolean isTypevalid(int type) throws OwnerException;

    Map<Integer,FlatOwner> getList() throws OwnerException;

	
}


