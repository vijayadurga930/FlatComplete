package com.cg.frs.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.frs.beans.FlatOwner;
import com.cg.frs.beans.FlatRegistrationDTO;
import com.cg.frs.dao.FlatRegistrationDaoImpl;
import com.cg.frs.dao.IFlatRegistrationDao;
import com.cg.frs.exception.OwnerException;
import com.cg.frs.utility.OwnerDb;

public class FlatRegistrationServiceImpl implements IFlatRegistrationService {
	FlatRegistrationDaoImpl dao=new FlatRegistrationDaoImpl();

	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) {
		
		return flat;
	}

	@Override
	public Map<Integer, FlatOwner> getAllOwnerIds() {
	
		return dao.getList();
	}

	@Override
	public boolean isNamevalid(String ownername) throws OwnerException {
		 Pattern nameptn=Pattern.compile("[A-Z]{1}[a-z]{5}");
	   	 Matcher match=nameptn.matcher(ownername);
	   	 if(match.matches()) {
	   		 return true;
	   	 }
		return false;
	}

	@Override
	public boolean isPhonevalid(String Mobilenum) throws OwnerException {
		Pattern phoneptn=Pattern.compile("[6-9]{1}[0-9]{9}");
		Matcher match=phoneptn.matcher(Mobilenum);
		if(match.matches())
		{
			return true;
		}
		return false;
	}

	public Map<Integer,FlatOwner> getList() {
		
		return dao.getList();
	}

	public static int getGeneratedId() throws OwnerException {
		 double generatedId=0;
		 generatedId=Math.random()*1000;
		 int id=(int)generatedId;
		return id;
	}

	public boolean isTypevalid(int type) throws OwnerException {
		boolean validtype=false;
		{
			if(type>0 && type<3) {
				validtype=true;
			}else {
				throw new OwnerException(" type must be 1 or 2");
			}
			return validtype;
		}
		
		
	}

	

}
