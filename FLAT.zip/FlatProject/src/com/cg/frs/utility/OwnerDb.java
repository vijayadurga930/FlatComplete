package com.cg.frs.utility;

import java.util.HashMap;
import java.util.Map;

import com.cg.frs.beans.FlatOwner;

public class OwnerDb {
 public static Map<Integer,FlatOwner> map=new HashMap<>();
 static {
	map.put(1,new FlatOwner(101," vaishali",902304));
	map.put(2,new FlatOwner(102,"Megha",9643221));
	map.put(3,new FlatOwner(103," Manish",545322));

	}

Map<Integer,OwnerDb> FlatDetails = new HashMap<>();

 public static   Map<Integer, FlatOwner> getMap(){
	  return map;
	 
 }
public static void setMap(Map<Integer,FlatOwner>map) {
	OwnerDb.map=map;
}
public static void getMap(Map<Integer,FlatOwner>map) {
	OwnerDb.map=map;
}
}