package com.cg.frs.exception;

public class OwnerException extends Exception{
 
	public OwnerException(String Message) {
		super(Message);
	}
	
}
