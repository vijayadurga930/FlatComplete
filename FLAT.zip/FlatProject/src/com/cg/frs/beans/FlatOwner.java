package com.cg.frs.beans;

import java.util.Collection;

public class FlatOwner {
	int OwnerId;
	String Ownername;
	float Mobilenum;
	@Override
	public String toString() {
		return "FlatOwner [OwnerId=" + OwnerId + ", Ownername=" + Ownername + ", Mobilenum=" + Mobilenum + "]";
	}
	public int getOwnerId() {
		return OwnerId;
	}
	public void setOwnerId(int ownerId) {
		OwnerId = ownerId;
	}
	public String getOwnername() {
		return Ownername;
	}
	public void setOwnername(String ownername) {
		Ownername = ownername;
	}
	public float getMobilenum() {
		return Mobilenum;
	}
	public void setMobilenum(float mobilenum) {
		Mobilenum = mobilenum;
	}
	public FlatOwner(int ownerId, String ownername, float mobilenum) {
		super();
		OwnerId = ownerId;
		Ownername = ownername;
		Mobilenum = mobilenum;
	}
	public FlatOwner() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public static void addAll(Collection<FlatOwner> collection) {
		// TODO Auto-generated method stub
		
	}

	

}
