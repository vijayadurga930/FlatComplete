package com.cg.frs.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.cg.frs.beans.FlatOwner;
import com.cg.frs.exception.OwnerException;
import com.cg.frs.service.FlatRegistrationServiceImpl;


public class Main {
  
	public static void main(String[] args) throws OwnerException {
		Scanner scanner=new Scanner(System.in);
		FlatRegistrationServiceImpl service=new FlatRegistrationServiceImpl();
		Map<Integer,FlatOwner>map=new HashMap<>();
		List<FlatOwner> list=new ArrayList();
		System.out.println("***welcome to flat regidtration***");
		System.out.println("1.Register Flat\n 2.display flat registration details\n 3.Exit");
		boolean choiceFlag=false;
		do {
					int choice=scanner.nextInt();
		switch (choice) {
					case 1: 
						boolean nameFlag=true;
						do{
					System.out.println("enter your name:");
						String Ownername=scanner.nextLine();
						try {
							nameFlag = service.isNamevalid(Ownername);
							if (!nameFlag) {
								throw new OwnerException("Invalid Name");
							}
						
						} catch (OwnerException e) {
							System.err.println(e.getMessage());
						}

					}while(!nameFlag);
						
						
					    boolean phoneFlag=false;
					    do {
						System.out.println("enter your mobile number: ");
						String Mobilenum=scanner.nextLine();
						try {
						phoneFlag=service.isPhonevalid(Mobilenum);
						if(!phoneFlag) 
								{
							throw new OwnerException("invalid number");
							}
						}
						catch(OwnerException e)
						{
							System.err.println(e.getMessage());
						}
					}while(!phoneFlag);
					    
					 boolean  typeFlag=false;
					do {
					System.out.println(" enter flat type: 1-1BHK 2-2BHK");
					int type=scanner.nextInt();
				   try {
					   typeFlag=service.isTypevalid(type);
					   if(!typeFlag) {
						   throw new OwnerException("invalid type ");
					   }   
					   }catch(OwnerException e) {
						   System.err.println(e.getMessage());
					   }
				   }while(!typeFlag);
					
					
					System.out.println(" enter flat area(in sq.ft):");
					double flatarea=scanner.nextDouble();	
					System.out.println("enter rent amount(in Rs): ");
					double rent=scanner.nextDouble();
					System.out.println("enter deposit amount(in Rs): ");
					double deposit=scanner.nextDouble();
					 
				int generatedId=0;
				try {
					generatedId = service.getGeneratedId();
					System.out.println(" Registered Successfully with id: "+generatedId);
				} catch (OwnerException e) {
					e.printStackTrace();
				}
		
			
			
				   case 2: 
				   {
					   System.out.println("Owners list ");
					   map=service.getList();
					   System.out.println(map);
				   }break;
				   default:
				   {
					   System.err.println("please select option from 1 to 3 ");
				   }break;
	   
				   	case 3:
				   	{
				   		System.out.println(" thank you for visiting");
				   		System.exit(0);
				   	}
		}
		}while(!choiceFlag);
		}
	
}



			   
			



					    
